package com.oleg.zipmailer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Store.list(c, "folders").isNotEmpty())
            ContextCompat.startForegroundService(c, Intent(c, WatchService::class.java))
    }
}
