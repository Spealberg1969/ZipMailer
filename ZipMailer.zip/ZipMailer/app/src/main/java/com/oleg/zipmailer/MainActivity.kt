package com.oleg.zipmailer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import kotlinx.coroutines.delay
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
            .launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable
    fun Screen() {
        val c = this
        var status by remember { mutableStateOf("") }
        LaunchedEffect(Unit) { while (true) { status = Store.get(c, "status"); delay(2000) } }
        var email by remember { mutableStateOf(Store.get(c, "email")) }
        var pass by remember { mutableStateOf(Store.get(c, "pass")) }
        var newTo by remember { mutableStateOf("") }
        val to = remember { mutableStateListOf<String>().apply { addAll(Store.list(c, "to")) } }
        val folders = remember { mutableStateListOf<String>().apply { addAll(Store.list(c, "folders")) } }

        val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
            if (u != null) {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                if (u.toString() !in folders) {
                    folders.add(u.toString()); Store.putList(c, "folders", folders)
                }
            }
        }

        Column(
            Modifier.systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Отправитель (Gmail)", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("Gmail адрес") }, singleLine = true)
            OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth(), label = { Text("Пароль приложения Google") },
                singleLine = true, visualTransformation = PasswordVisualTransformation())
            Button({
                try {
                    Store.put(c, "email", email.trim()); Store.put(c, "pass", pass.replace(" ", ""))
                    Toast.makeText(c, "Сохранено", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) { Toast.makeText(c, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show() }
            }) { Text("Сохранить") }
            OutlinedButton({
                Toast.makeText(c, "Проверяю вход в Gmail…", Toast.LENGTH_SHORT).show()
                Thread {
                    val msg = try {
                        Mailer.checkLogin(c); "Вход в Gmail выполнен ✔"
                    } catch (e: javax.mail.AuthenticationFailedException) {
                        "Gmail не принял пароль. Нужен пароль приложения (16 символов), а не обычный пароль"
                    } catch (e: Exception) {
                        "Ошибка: ${e.message}"
                    }
                    runOnUiThread { Toast.makeText(c, msg, Toast.LENGTH_LONG).show() }
                }.start()
            }) { Text("Проверить вход в Gmail") }

            HorizontalDivider()
            Text("Получатели", style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(newTo, { newTo = it }, Modifier.weight(1f), label = { Text("Email") }, singleLine = true)
                TextButton({
                    val a = newTo.trim()
                    if (a.contains("@") && a !in to) { to.add(a); Store.putList(c, "to", to) }
                    newTo = ""
                }) { Text("Добавить") }
            }
            to.toList().forEach { a ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(a, Modifier.weight(1f))
                    TextButton({ to.remove(a); Store.putList(c, "to", to) }) { Text("✕") }
                }
            }

            HorizontalDivider()
            Text("Папки со ZIP", style = MaterialTheme.typography.titleMedium)
            Button({ pick.launch(null) }) { Text("Добавить папку") }
            folders.toList().forEach { f ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(Uri.parse(f).lastPathSegment ?: f, Modifier.weight(1f))
                    TextButton({
                        folders.remove(f); Store.putList(c, "folders", folders); Store.put(c, "base:$f", "")
                    }) { Text("✕") }
                }
            }

            HorizontalDivider()
            Text("Статус: " + status.ifBlank { "не запущено" })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({
                    val problem = when {
                        Store.get(c, "email").isBlank() || Store.get(c, "pass").isBlank() -> "Введи Gmail и пароль и нажми «Сохранить»"
                        to.isEmpty() -> "Добавь получателя"
                        folders.isEmpty() -> "Добавь папку"
                        else -> null
                    }
                    if (problem != null) Toast.makeText(c, problem, Toast.LENGTH_LONG).show()
                    else try {
                        ContextCompat.startForegroundService(c, Intent(c, WatchService::class.java))
                        Toast.makeText(c, "Запущено", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) { Toast.makeText(c, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show() }
                }) { Text("Старт") }
                OutlinedButton({ stopService(Intent(c, WatchService::class.java)) }) { Text("Стоп") }
            }
            OutlinedButton({ startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) {
                Text("Настройки батареи")
            }
        }
    }
}
