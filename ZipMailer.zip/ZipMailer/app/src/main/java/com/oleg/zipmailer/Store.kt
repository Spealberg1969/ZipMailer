package com.oleg.zipmailer

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object Store {
    private var cache: android.content.SharedPreferences? = null
    private fun p(c: Context) = cache ?: create(c.applicationContext).also { cache = it }
    private fun create(c: Context) = EncryptedSharedPreferences.create(
        c, "zipmailer",
        MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun get(c: Context, k: String): String = p(c).getString(k, "") ?: ""
    fun put(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()
    fun list(c: Context, k: String): MutableList<String> =
        get(c, k).split("\n").filter { it.isNotBlank() }.toMutableList()
    fun putList(c: Context, k: String, l: List<String>) = put(c, k, l.joinToString("\n"))
}
