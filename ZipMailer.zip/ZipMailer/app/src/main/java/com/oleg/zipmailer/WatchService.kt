package com.oleg.zipmailer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.*

class WatchService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val sizes = HashMap<String, Long>()
    private val failUntil = HashMap<String, Long>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("w", "Zip Mailer", NotificationManager.IMPORTANCE_LOW))
        ServiceCompat.startForeground(this, 1, note("Слежу за папками"), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        status("Слежу за папками")
        scope.coroutineContext.cancelChildren()
        scope.launch {
            while (isActive) {
                try { scan() } catch (e: Exception) { status("Ошибка: ${e.message}") }
                delay(15_000)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() { scope.cancel() }

    private fun note(t: String) = NotificationCompat.Builder(this, "w")
        .setSmallIcon(android.R.drawable.ic_dialog_email)
        .setContentTitle("Zip Mailer").setContentText(t).setOngoing(true).build()

    private fun status(t: String) {
        val line = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()) + "  " + t
        Store.put(this, "status", line)
        getSystemService(NotificationManager::class.java).notify(1, note(t))
    }

    private fun key(d: DocumentFile) = "${d.uri}|${d.lastModified()}|${d.length()}"

    private fun scan() {
        for (f in Store.list(this, "folders")) {
            val dir = DocumentFile.fromTreeUri(this, Uri.parse(f)) ?: continue
            val zips = dir.listFiles().filter { it.isFile && it.name?.endsWith(".zip", true) == true }
            val sent = Store.list(this, "sent")

            // Первый проход по папке: старые архивы не отправляем
            if (Store.get(this, "base:$f").isEmpty()) {
                sent += zips.map { key(it) }
                Store.putList(this, "sent", sent.takeLast(1000))
                Store.put(this, "base:$f", "1")
                continue
            }
            for (z in zips) {
                val k = key(z)
                if (k in sent) continue
                // ждём, пока файл допишется: размер не меняется и прошло 5+ секунд
                val prev = sizes.put(k, z.length())
                if (prev != z.length() || System.currentTimeMillis() - z.lastModified() < 5_000) continue
                if ((failUntil[k] ?: 0L) > System.currentTimeMillis()) continue
                try {
                    Mailer.send(this, z)
                    Store.putList(this, "sent", (Store.list(this, "sent") + k).takeLast(1000))
                    status("Отправлено: ${z.name}")
                } catch (e: Exception) {
                    failUntil[k] = System.currentTimeMillis() + 120_000
                    status("Ошибка ${z.name}: ${e.message}")
                }
            }
        }
    }
}
