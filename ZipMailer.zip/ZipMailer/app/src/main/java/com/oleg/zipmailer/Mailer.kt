package com.oleg.zipmailer

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import java.io.InputStream
import java.io.OutputStream
import java.util.Properties
import javax.activation.DataHandler
import javax.activation.DataSource
import javax.mail.Authenticator
import javax.mail.Message
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart

object Mailer {
    const val MAX_BYTES = 18_000_000L // ~25 MB лимит Gmail с учётом base64

    fun checkLogin(c: Context) {
        val user = Store.get(c, "email")
        val pass = Store.get(c, "pass")
        require(user.isNotBlank() && pass.isNotBlank()) { "Введи Gmail и пароль и нажми «Сохранить»" }
        val props = Properties().apply {
            put("mail.smtp.auth", "true")
            put("mail.smtp.starttls.enable", "true")
            put("mail.smtp.host", "smtp.gmail.com")
            put("mail.smtp.port", "587")
        }
        val t = Session.getInstance(props).getTransport("smtp")
        t.connect("smtp.gmail.com", 587, user, pass)
        t.close()
    }

    fun send(c: Context, z: DocumentFile) {
        val user = Store.get(c, "email")
        val pass = Store.get(c, "pass")
        val to = Store.list(c, "to")
        require(user.isNotBlank() && pass.isNotBlank() && to.isNotEmpty()) { "Не заполнены настройки" }
        require(z.length() <= MAX_BYTES) { "Файл больше 18 МБ" }
        val name = z.name ?: "archive.zip"

        val props = Properties().apply {
            put("mail.smtp.auth", "true")
            put("mail.smtp.starttls.enable", "true")
            put("mail.smtp.host", "smtp.gmail.com")
            put("mail.smtp.port", "587")
            put("mail.mime.encodefilename", "true")
        }
        val session = Session.getInstance(props, object : Authenticator() {
            override fun getPasswordAuthentication() = PasswordAuthentication(user, pass)
        })
        val ds = object : DataSource {
            override fun getInputStream(): InputStream = c.contentResolver.openInputStream(z.uri)!!
            override fun getOutputStream(): OutputStream = throw UnsupportedOperationException()
            override fun getContentType() = "application/zip"
            override fun getName() = name
        }
        val msg = MimeMessage(session).apply {
            setFrom(InternetAddress(user))
            setRecipients(Message.RecipientType.TO, InternetAddress.parse(to.joinToString(",")))
            setSubject(name, "UTF-8")
            setContent(MimeMultipart().apply {
                addBodyPart(MimeBodyPart().apply { setText("Файл: $name", "UTF-8") })
                addBodyPart(MimeBodyPart().apply {
                    dataHandler = DataHandler(ds)
                    fileName = name
                })
            })
        }
        Transport.send(msg)
    }
}
